@props(['provider'])
<a href="#"
   class="btn btn-warning btn-sm js-open-modal"
   data-url="{{ route('admin.apis.edit', $provider) }}">
  Edit
</a>
