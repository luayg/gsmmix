@props(['provider'])
<a href="#" class="btn btn-primary btn-sm js-open-modal"
   data-url="{{ route('admin.apis.view', $provider) }}">View</a>
