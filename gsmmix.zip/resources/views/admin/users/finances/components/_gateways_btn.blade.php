<button class="btn btn-outline-secondary" data-fin-url="{{ route('admin.users.finances.gateways',$user) }}">Manage payment gateways</button>
