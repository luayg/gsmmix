<button class="btn btn-primary" data-fin-url="{{ route('admin.users.finances.statement',$user) }}?view=1">Statement</button>
