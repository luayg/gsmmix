<button class="btn btn-success" data-fin-url="{{ route('admin.users.finances.add_payment',$user) }}?view=1">Add payment</button>
