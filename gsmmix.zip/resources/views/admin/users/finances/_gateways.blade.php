<div class="card card-body">
  <div class="text-muted">Gateways manager (placeholder)</div>
</div>
