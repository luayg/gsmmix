{{-- [انسخ] --}}
@extends('layouts.admin')
@section('title','Dashboard')

@section('content')
<div class="card">
  <div class="card-body">
    <h5 class="card-title mb-3"><i class="fas fa-tachometer-alt mr-2"></i>Dashboard</h5>
    <p class="mb-0">مرحباً بك في لوحة التحكم.</p>
  </div>
</div>
@endsection
